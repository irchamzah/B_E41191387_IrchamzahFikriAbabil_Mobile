package com.inyongtisto.tokoonline.model.rajaongkir

import com.inyongtisto.tokoonline.model.ModelAlamat

class Result {
    val name = ""
    val code = ""
    val costs = ArrayList<Costs>()
}