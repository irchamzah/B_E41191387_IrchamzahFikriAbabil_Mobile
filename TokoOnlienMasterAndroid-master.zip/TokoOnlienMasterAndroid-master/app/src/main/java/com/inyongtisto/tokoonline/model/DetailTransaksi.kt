package com.inyongtisto.tokoonline.model

class DetailTransaksi {
    var total_item = 0
    var total_harga = 0
    var produk = Produk()
}