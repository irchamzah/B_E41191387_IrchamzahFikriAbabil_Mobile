package com.inyongtisto.tokoonline.model.rajaongkir

import com.inyongtisto.tokoonline.model.ModelAlamat

class Cost {
    val value = ""
    val etd = ""
    val note = ""
}