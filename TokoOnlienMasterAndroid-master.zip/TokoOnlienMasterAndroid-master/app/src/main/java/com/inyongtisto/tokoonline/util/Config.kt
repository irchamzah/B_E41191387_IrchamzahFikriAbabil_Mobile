package com.inyongtisto.tokoonline.util

/**
 * Created by Tisto on 1/11/2021.
 */
object Config {
    const val baseUrl2 = "http://192.168.43.162/tokoonline/public/"
    const val productUrl = baseUrl2 + "storage/produk/"
}