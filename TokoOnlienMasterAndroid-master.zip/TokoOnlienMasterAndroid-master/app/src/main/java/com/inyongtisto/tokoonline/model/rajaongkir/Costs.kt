package com.inyongtisto.tokoonline.model.rajaongkir

import com.inyongtisto.tokoonline.model.ModelAlamat

class Costs {
    val service = ""
    val description = ""
    val cost = ArrayList<Cost>()
    var isActive = false
}